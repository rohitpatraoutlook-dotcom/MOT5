"""
Memory Vault - Fixed Version with Metadata
"""
import json
import hashlib
from datetime import datetime

class MemoryVault:
    def __init__(self):
        self.invariant_store = {}
        self.gene_library = {}
        self.transition_rules = {}
        self.region_maps = {}
        self.evolutionary_flow = []
        self.next_gene_id = 1
        self.metadata = {
            "total_runs": 0,
            "last_updated": datetime.now().isoformat(),
            "version": "1.0.0",
            "created": datetime.now().isoformat()
        }
    
    def write_invariant(self, hash_key, R_expr, K_expr, metric, topology='unknown'):
        """Store invariant - append only"""
        # Update metadata on every write
        self.metadata["total_runs"] += 1
        self.metadata["last_updated"] = datetime.now().isoformat()
        
        if hash_key in self.invariant_store:
            self.invariant_store[hash_key]['frequency'] += 1
            self.invariant_store[hash_key]['trust_score'] = min(
                1.0, self.invariant_store[hash_key]['trust_score'] + 0.05
            )
        else:
            self.invariant_store[hash_key] = {
                'R_expr': str(R_expr),
                'K_expr': str(K_expr),
                'metric': str(metric),
                'metric_type': type(metric).__name__,
                'topology': topology,
                'frequency': 1,
                'trust_score': 0.5
            }
        return True
    
    def write_gene(self, expr, domain='general'):
        """Store reusable expression - append only"""
        gene_id = f"G_{self.next_gene_id:04d}"
        self.next_gene_id += 1
        
        self.gene_library[gene_id] = {
            'expr': str(expr),
            'domain': domain,
            'success_rate': 0.5,
            'used_count': 1
        }
        return gene_id
    
    def write_transition(self, parent_hash, child_hash, residual, scale_factor=10):
        """Store scale-transition rule"""
        key = f"{parent_hash}→{child_hash}"
        if key in self.transition_rules:
            self.transition_rules[key]['confidence'] += 0.02
        else:
            self.transition_rules[key] = {
                'residual': str(residual),
                'scale_factor': scale_factor,
                'confidence': 0.5,
                'used_count': 1
            }
        return True
    
    def read_invariant(self, hash_key):
        return self.invariant_store.get(hash_key, None)
    
    def read_genes(self, domain='all', max_count=5):
        genes = []
        for gid, data in self.gene_library.items():
            if domain == 'all' or data['domain'] == domain:
                genes.append((gid, data))
        genes.sort(key=lambda x: x[1]['success_rate'], reverse=True)
        return genes[:max_count]
    
    def read_transition(self, parent_hash):
        results = []
        for key, data in self.transition_rules.items():
            if key.startswith(parent_hash):
                results.append((key, data))
        return results
    
    def get_metadata(self):
        """Get memory statistics"""
        return {
            "total_runs": self.metadata["total_runs"],
            "invariants_count": len(self.invariant_store),
            "genes_count": len(self.gene_library),
            "transitions_count": len(self.transition_rules),
            "last_updated": self.metadata["last_updated"]
        }
    
    def save(self, filepath):
        """Save memory to JSON"""
        data = {
            'invariant_store': self.invariant_store,
            'gene_library': self.gene_library,
            'transition_rules': self.transition_rules,
            'region_maps': self.region_maps,
            'evolutionary_flow': self.evolutionary_flow,
            'next_gene_id': self.next_gene_id,
            'metadata': self.metadata
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        return True
    
    def load(self, filepath):
        """Load memory from JSON"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
                self.invariant_store = data.get('invariant_store', {})
                self.gene_library = data.get('gene_library', {})
                self.transition_rules = data.get('transition_rules', {})
                self.region_maps = data.get('region_maps', {})
                self.evolutionary_flow = data.get('evolutionary_flow', [])
                self.next_gene_id = data.get('next_gene_id', 1)
                self.metadata = data.get('metadata', self.metadata)
            return True
        except Exception as e:
            print(f"⚠️ Error loading memory: {e}")
            return False
    
    def clear(self):
        """Clear all memory (for testing)"""
        self.invariant_store = {}
        self.gene_library = {}
        self.transition_rules = {}
        self.region_maps = {}
        self.evolutionary_flow = []
        self.next_gene_id = 1
        self.metadata["total_runs"] = 0
        self.metadata["last_updated"] = datetime.now().isoformat()
